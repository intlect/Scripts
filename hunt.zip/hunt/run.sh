#!/bin/bash

pip install -r requirements.txt
pip3 install -r requirements.txt
clear
python ethunter.py; python3 ethunter.py
